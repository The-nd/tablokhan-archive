# تابلوخوان

این بسته فقط شامل کد برنامه است و مدل‌ها داخل آن نیستند.

برای دانلود مدل‌ها و راهنمای نصب، به گیتهاب پروژه مراجعه کنید:

https://github.com/AliNajafpour/tablokhan-ocr

مدل‌ها را پس از دریافت در مسیرهای زیر، کنار فایل main.py قرار دهید:

```text
models/detection/PP-OCRv6_medium_det/
models/recognition/arabic-train-v1/
```

هر پوشه باید شامل inference.json، inference.pdiparams و inference.yml باشد.

اجرای نسخه فعلی به Python 3.11، کارت NVIDIA و نصب وابستگی‌های سازگار Paddle GPU/CUDA نیاز دارد.

```bash
pip install -r requirements.txt
python main.py
```

سپس http://127.0.0.1:8000 را در مرورگر باز کنید.
